const BankModule = {
        currentAccount: null,
        gameActive: false,
        transactions: [],
        creditScore: 750,
        loanAmount: 0,
        loanInterest: 0,

        init() {
            this.createBankAccount();
        },

        createBankAccount() {
            this.currentAccount = {
                balance: 50000,
                accountType: 'Savings',
                interestRate: 0.035, // 3.5% annual interest
                monthlyFee: 0,
                overdraftLimit: 5000,
                creditLimit: 100000,
                availableCredit: 100000
            };
        },

        renderBankInterface() {
            const container = document.getElementById('bank');
            const user = UserModule.loadUser();

            container.innerHTML = `
            <div class="bank-header">
                <h2><i class="fas fa-university"></i> Banking & Credit Simulator</h2>
                <div class="account-summary">
                    <div class="summary-item">
                        <span class="label">Account Balance</span>
                        <span class="value">₹${this.currentAccount.balance.toLocaleString()}</span>
                    </div>
                    <div class="summary-item">
                        <span class="label">Available Credit</span>
                        <span class="value">₹${this.currentAccount.availableCredit.toLocaleString()}</span>
                    </div>
                    <div class="summary-item">
                        <span class="label">Credit Score</span>
                        <span class="value">${this.creditScore}</span>
                    </div>
                </div>
            </div>

            <div class="bank-actions">
                <div class="action-section">
                    <h3><i class="fas fa-piggy-bank"></i> Account Management</h3>
                    <div class="action-grid">
                        <div class="action-item">
                            <input type="number" id="depositAmount" placeholder="₹ Amount" min="100" step="100">
                            <button class="btn-deposit" id="depositBtn">
                                <i class="fas fa-plus"></i> Deposit
                            </button>
                        </div>
                        <div class="action-item">
                            <input type="number" id="withdrawAmount" placeholder="₹ Amount" min="100" step="100">
                            <button class="btn-withdraw" id="withdrawBtn">
                                <i class="fas fa-minus"></i> Withdraw
                            </button>
                        </div>
                    </div>
                </div>

                <div class="action-section">
                    <h3><i class="fas fa-credit-card"></i> Credit Card</h3>
                    <div class="action-grid">
                        <div class="action-item">
                            <input type="number" id="chargeAmount" placeholder="₹ Amount" min="100" step="100">
                            <button class="btn-charge" id="chargeBtn">
                                <i class="fas fa-shopping-cart"></i> Make Purchase
                            </button>
                        </div>
                        <div class="action-item">
                            <input type="number" id="paymentAmount" placeholder="₹ Amount" min="100" step="100">
                            <button class="btn-payment" id="paymentBtn">
                                <i class="fas fa-credit-card"></i> Pay Bill
                            </button>
                        </div>
                    </div>
                </div>

                <div class="action-section">
                    <h3><i class="fas fa-hand-holding-usd"></i> Loans</h3>
                    <div class="loan-info">
                        ${this.loanAmount > 0 ? `
                            <div class="current-loan">
                                <p><strong>Current Loan:</strong> ₹${this.loanAmount.toLocaleString()}</p>
                                <p><strong>Monthly Interest:</strong> ₹${this.loanInterest.toLocaleString()}</p>
                            </div>
                        ` : '<p>No active loans</p>'}
                    </div>
                    <div class="action-grid">
                        <div class="action-item">
                            <input type="number" id="loanRequest" placeholder="₹ Amount" min="10000" step="10000" max="500000">
                            <button class="btn-loan" id="loanBtn">
                                <i class="fas fa-file-contract"></i> Apply for Loan
                            </button>
                        </div>
                        <div class="action-item">
                            <button class="btn-repay" id="repayBtn">
                                <i class="fas fa-money-bill-wave"></i> Repay Loan
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="transaction-history">
                <h3><i class="fas fa-history"></i> Recent Transactions</h3>
                <div class="transaction-list" id="transactionList">
                    ${this.transactions.length > 0 ?
                        this.transactions.slice(-5).reverse().map(t => `
                            <div class="transaction-item ${t.type}">
                                <div class="transaction-icon">
                                    <i class="fas ${this.getTransactionIcon(t.type)}"></i>
                                </div>
                                <div class="transaction-details">
                                    <div class="transaction-desc">${t.description}</div>
                                    <div class="transaction-amount ${t.amount > 0 ? 'positive' : 'negative'}">
                                        ${t.amount > 0 ? '+' : ''}₹${Math.abs(t.amount).toLocaleString()}
                                    </div>
                                </div>
                                <div class="transaction-date">${t.date}</div>
                            </div>
                        `).join('') :
                        '<div class="no-transactions">No transactions yet</div>'
                    }
                </div>
            </div>

            <div class="banking-tips">
                <h4><i class="fas fa-lightbulb"></i> Banking Tip</h4>
                <p id="bankTip">${this.getRandomBankTip()}</p>
            </div>
        `;

        this.updateTransactionList();
    },

    setupEventListeners() {
        // Deposit
        document.getElementById('depositBtn').addEventListener('click', () => {
            const amount = parseFloat(document.getElementById('depositAmount').value);
            if (amount > 0) {
                this.deposit(amount);
                document.getElementById('depositAmount').value = '';
            }
        });

        // Withdraw
        document.getElementById('withdrawBtn').addEventListener('click', () => {
            const amount = parseFloat(document.getElementById('withdrawAmount').value);
            if (amount > 0) {
                this.withdraw(amount);
                document.getElementById('withdrawAmount').value = '';
            }
        });

        // Credit card charge
        document.getElementById('chargeBtn').addEventListener('click', () => {
            const amount = parseFloat(document.getElementById('chargeAmount').value);
            if (amount > 0) {
                this.makeCreditPurchase(amount);
                document.getElementById('chargeAmount').value = '';
            }
        });

        // Pay bill
        document.getElementById('paymentBtn').addEventListener('click', () => {
            const amount = parseFloat(document.getElementById('paymentAmount').value);
            if (amount > 0) {
                this.payBill(amount);
                document.getElementById('paymentAmount').value = '';
            }
        });

        // Apply for loan
        document.getElementById('loanBtn').addEventListener('click', () => {
            const amount = parseFloat(document.getElementById('loanRequest').value);
            if (amount > 0) {
                this.applyForLoan(amount);
                document.getElementById('loanRequest').value = '';
            }
        });

        // Repay loan
        document.getElementById('repayBtn').addEventListener('click', () => {
            this.repayLoan();
        });
    },

    deposit(amount) {
        this.currentAccount.balance += amount;
        this.addTransaction('deposit', amount, `Deposit to ${this.currentAccount.accountType} Account`);
        this.updateUI();
        UIModule.showNotification(`✅ Deposited ₹${amount.toLocaleString()} successfully!`, 'success');
    },

    withdraw(amount) {
        if (amount > this.currentAccount.balance + this.currentAccount.overdraftLimit) {
            UIModule.showNotification('❌ Insufficient funds!', 'error');
            return;
        }

        this.currentAccount.balance -= amount;
        this.addTransaction('withdrawal', -amount, `Withdrawal from ${this.currentAccount.accountType} Account`);
        this.updateUI();
        UIModule.showNotification(`✅ Withdrew ₹${amount.toLocaleString()} successfully!`, 'success');
    },

    makeCreditPurchase(amount) {
        if (amount > this.currentAccount.availableCredit) {
            UIModule.showNotification('❌ Insufficient credit limit!', 'error');
            return;
        }

        this.currentAccount.availableCredit -= amount;
        this.addTransaction('credit_charge', -amount, 'Credit Card Purchase');
        this.updateUI();
        UIModule.showNotification(`✅ Charged ₹${amount.toLocaleString()} to credit card!`, 'success');
    },

    payBill(amount) {
        if (amount > this.currentAccount.balance) {
            UIModule.showNotification('❌ Insufficient funds!', 'error');
            return;
        }

        this.currentAccount.balance -= amount;
        this.currentAccount.availableCredit += Math.min(amount, this.currentAccount.creditLimit - this.currentAccount.availableCredit);
        this.addTransaction('payment', -amount, 'Credit Card Payment');
        this.updateUI();
        UIModule.showNotification(`✅ Paid ₹${amount.toLocaleString()} towards credit card!`, 'success');
    },

    applyForLoan(amount) {
        if (this.loanAmount > 0) {
            UIModule.showNotification('❌ You already have an active loan!', 'warning');
            return;
        }

        if (this.creditScore < 600) {
            UIModule.showNotification('❌ Credit score too low for loan approval!', 'error');
            return;
        }

        this.loanAmount = amount;
        this.loanInterest = Math.round(amount * 0.12 / 12); // 12% annual interest, monthly
        this.currentAccount.balance += amount;
        this.addTransaction('loan', amount, `Loan Approved - ₹${amount.toLocaleString()}`);
        this.updateUI();
        UIModule.showNotification(`✅ Loan of ₹${amount.toLocaleString()} approved!`, 'success');
    },

    repayLoan() {
        if (this.loanAmount <= 0) {
            UIModule.showNotification('❌ No active loan to repay!', 'warning');
            return;
        }

        const totalRepayment = this.loanAmount + this.loanInterest;
        if (totalRepayment > this.currentAccount.balance) {
            UIModule.showNotification('❌ Insufficient funds to repay loan!', 'error');
            return;
        }

        this.currentAccount.balance -= totalRepayment;
        this.addTransaction('repayment', -totalRepayment, `Loan Repayment - ₹${totalRepayment.toLocaleString()}`);
        this.loanAmount = 0;
        this.loanInterest = 0;
        this.updateUI();
        UIModule.showNotification(`✅ Loan repaid successfully!`, 'success');
    },

    addTransaction(type, amount, description) {
        const transaction = {
            type: type,
            amount: amount,
            description: description,
            date: new Date().toLocaleDateString()
        };
        this.transactions.push(transaction);
        this.updateTransactionList();
    },

    updateTransactionList() {
        const list = document.getElementById('transactionList');
        if (this.transactions.length > 0) {
            list.innerHTML = this.transactions.slice(-5).reverse().map(t => `
                <div class="transaction-item ${t.type}">
                    <div class="transaction-icon">
                        <i class="fas ${this.getTransactionIcon(t.type)}"></i>
                    </div>
                    <div class="transaction-details">
                        <div class="transaction-desc">${t.description}</div>
                        <div class="transaction-amount ${t.amount > 0 ? 'positive' : 'negative'}">
                            ${t.amount > 0 ? '+' : ''}₹${Math.abs(t.amount).toLocaleString()}
                        </div>
                    </div>
                    <div class="transaction-date">${t.date}</div>
                </div>
            `).join('');
        } else {
            list.innerHTML = '<div class="no-transactions">No transactions yet</div>';
        }
    },

    updateUI() {
        document.querySelector('.summary-item:nth-child(1) .value').textContent = `₹${this.currentAccount.balance.toLocaleString()}`;
        document.querySelector('.summary-item:nth-child(2) .value').textContent = `₹${this.currentAccount.availableCredit.toLocaleString()}`;
        document.querySelector('.summary-item:nth-child(3) .value').textContent = this.creditScore;
        this.renderBankInterface();
    },

    getTransactionIcon(type) {
        const icons = {
            'deposit': 'fa-plus',
            'withdrawal': 'fa-minus',
            'credit_charge': 'fa-credit-card',
            'payment': 'fa-money-bill-wave',
            'loan': 'fa-file-contract',
            'repayment': 'fa-hand-holding-usd'
        };
        return icons[type] || 'fa-exchange-alt';
    },

    getRandomBankTip() {
        const tips = [
            "Pay your credit card bills on time to maintain a good credit score.",
            "Keep an emergency fund of 3-6 months of expenses.",
            "Avoid using your credit card for impulse purchases.",
            "Regularly check your account statements for errors.",
            "Save a portion of your income before spending it.",
            "Compare interest rates before taking a loan.",
            "Use online banking for convenient transactions.",
            "Set up automatic savings transfers to build wealth gradually."
        ];
        return tips[Math.floor(Math.random() * tips.length)];
    }
};

// Add CSS for bank module
const bankCSS = `
<style>
.bank-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 20px;
    border-radius: 15px;
    margin-bottom: 25px;
    text-align: center;
}

.bank-header h2 {
    margin: 0 0 15px 0;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.account-summary {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 20px;
}

.summary-item {
    background: rgba(255, 255, 255, 0.1);
    padding: 15px;
    border-radius: 10px;
    backdrop-filter: blur(10px);
}

.summary-item .label {
    display: block;
    font-size: 0.9em;
    opacity: 0.8;
    margin-bottom: 5px;
}

.summary-item .value {
    display: block;
    font-size: 1.5em;
    font-weight: bold;
}

.bank-actions {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 25px;
    margin-bottom: 30px;
}

.action-section {
    background: #f8fafc;
    padding: 20px;
    border-radius: 15px;
    border: 2px solid #e2e8f0;
}

.action-section h3 {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 15px;
    color: #1e293b;
    font-size: 1.1em;
}

.action-grid {
    display: grid;
    gap: 15px;
}

.action-item {
    display: flex;
    gap: 10px;
    align-items: center;
}

.action-item input {
    flex: 1;
    padding: 10px 15px;
    border: 2px solid #e2e8f0;
    border-radius: 8px;
    font-size: 1em;
}

.action-item button {
    padding: 10px 20px;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s ease;
}

.btn-deposit {
    background: linear-gradient(135deg, #10b981, #22c55e);
    color: white;
}

.btn-withdraw {
    background: linear-gradient(135deg, #ef4444, #dc2626);
    color: white;
}

.btn-charge {
    background: linear-gradient(135deg, #f59e0b, #f97316);
    color: white;
}

.btn-payment {
    background: linear-gradient(135deg, #3b82f6, #1d4ed8);
    color: white;
}

.btn-loan {
    background: linear-gradient(135deg, #8b5cf6, #7c3aed);
    color: white;
}

.btn-repay {
    background: linear-gradient(135deg, #06b6d4, #0891b2);
    color: white;
}

.action-item button:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}

.loan-info {
    margin-bottom: 15px;
    padding: 15px;
    background: white;
    border-radius: 8px;
    border: 1px solid #e2e8f0;
}

.current-loan p {
    margin: 5px 0;
    color: #475569;
}

.transaction-history {
    background: #f8fafc;
    padding: 20px;
    border-radius: 15px;
    border: 2px solid #e2e8f0;
    margin-bottom: 25px;
}

.transaction-history h3 {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 15px;
    color: #1e293b;
    font-size: 1.1em;
}

.transaction-list {
    max-height: 300px;
    overflow-y: auto;
}

.transaction-item {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 12px;
    background: white;
    border-radius: 8px;
    border: 1px solid #e2e8f0;
    margin-bottom: 8px;
}

.transaction-icon {
    width: 40px;
    height: 40px;
    background: #f1f5f9;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6366f1;
}

.transaction-details {
    flex: 1;
}

.transaction-desc {
    font-weight: 500;
    color: #1e293b;
    margin-bottom: 2px;
}

.transaction-amount {
    font-weight: bold;
}

.transaction-amount.positive {
    color: #10b981;
}

.transaction-amount.negative {
    color: #ef4444;
}

.transaction-date {
    font-size: 0.9em;
    color: #64748b;
}

.no-transactions {
    text-align: center;
    padding: 40px 20px;
    color: #64748b;
    font-style: italic;
}

.banking-tips {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 20px;
    border-radius: 15px;
    text-align: center;
}

.banking-tips h4 {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 15px;
    font-size: 1.1em;
}

.banking-tips p {
    font-size: 1.1em;
    opacity: 0.9;
}

@media (max-width: 768px) {
    .account-summary {
        grid-template-columns: 1fr;
    }

    .bank-actions {
        grid-template-columns: 1fr;
    }

    .action-item {
        flex-direction: column;
        gap: 8px;
    }

    .transaction-item {
        flex-direction: column;
        text-align: center;
        gap: 8px;
    }
}
</style>
`;

document.head.insertAdjacentHTML('beforeend', bankCSS);