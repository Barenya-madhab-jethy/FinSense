const UserModule = {
    createNewUser() {
        const user = {
            id: Date.now(),
            name: 'Player',
            avatar: 1,
            persona: 'balanced',
            level: 1,
            xp: 0,
            coins: 1000,
            badges: [],
            decisions: [],
            streak: 0,
            lastDailyClaim: null,
            quizStats: {
                totalCorrect: 0,
                totalAttempted: 0,
                bestStreak: 0
            },
            budgetStats: {
                totalSaved: 0,
                monthsCompleted: 0
            },
            investStats: {
                totalReturn: 0,
                tradesMade: 0
            }
        };

        this.saveUser(user);
        return user;
    },

    saveUser(user) {
        localStorage.setItem('finsense_user', JSON.stringify(user));
    },

    loadUser() {
        const userData = localStorage.getItem('finsense_user');
        return userData ? JSON.parse(userData) : null;
    },

    updateXP(amount) {
        const user = this.loadUser();
        user.xp += amount;

        // Level up every 1000 XP
        const newLevel = Math.floor(user.xp / 1000) + 1;
        if (newLevel > user.level) {
            user.level = newLevel;
            this.showLevelUp(newLevel);
        }

        this.saveUser(user);
        return user;
    },

    showLevelUp(level) {
        const notification = {
            type: 'levelup',
            message: `🎉 Level Up! You reached Level ${level}!`,
            coins: level * 100
        };

        UIModule.showNotification(notification.message, 'success');

        // Add bonus coins
        const user = this.loadUser();
        user.coins += notification.coins;
        this.saveUser(user);

        // Show confetti
        UIModule.showConfetti();
    }
};