const QuizModule = {
    currentQuiz: null,
    questions: [],
    currentQuestionIndex: 0,
    score: 0,
    streak: 0,
    timer: null,
    timeLeft: 60,
    gameActive: false,

    init() {
        this.loadQuestions();
        this.renderQuizInterface();
        this.setupEventListeners();
    },

    loadQuestions() {
        this.questions = [{
                question: "What is compound interest?",
                options: [
                    "Interest paid only on the principal amount",
                    "Interest paid on both principal and accumulated interest",
                    "Interest paid monthly regardless of balance",
                    "Interest that decreases over time"
                ],
                correct: 1,
                explanation: "Compound interest is interest calculated on the initial principal and also on the accumulated interest from previous periods."
            },
            {
                question: "Which of these is considered a fixed expense?",
                options: [
                    "Groceries",
                    "Rent/Mortgage",
                    "Entertainment",
                    "Dining out"
                ],
                correct: 1,
                explanation: "Fixed expenses like rent or mortgage payments remain the same each month, unlike variable expenses that can fluctuate."
            },
            {
                question: "What is diversification in investing?",
                options: [
                    "Putting all money in one stock",
                    "Spreading investments across different assets",
                    "Only investing in bonds",
                    "Trading frequently for quick profits"
                ],
                correct: 1,
                explanation: "Diversification means spreading your investments across different asset classes to reduce risk."
            },
            {
                question: "What is an emergency fund?",
                options: [
                    "Money saved for vacations",
                    "Money set aside for unexpected expenses",
                    "Money invested in stocks",
                    "Money used for daily expenses"
                ],
                correct: 1,
                explanation: "An emergency fund is money saved specifically to cover unexpected expenses like medical bills or car repairs."
            },
            {
                question: "Which has higher risk but potentially higher returns?",
                options: [
                    "Savings account",
                    "Government bonds",
                    "Stocks",
                    "Fixed deposits"
                ],
                correct: 2,
                explanation: "Stocks generally have higher risk but offer higher potential returns compared to safer investments like savings accounts."
            }
        ];
    },

    renderQuizInterface() {
        const container = document.getElementById('quizContainer');
        container.innerHTML = `
            <div class="quiz-welcome">
                <h3>Test Your Financial Knowledge!</h3>
                <p>Answer questions correctly to earn coins and XP. Wrong answers reset your streak!</p>
                <button class="btn-start-quiz" id="startQuizBtn">
                    <i class="fas fa-play"></i> Start Quiz
                </button>
            </div>

            <div class="quiz-game" id="quizGame" style="display: none;">
                <div class="question-card">
                    <div class="question-header">
                        <span class="question-number" id="questionNumber">Question 1/5</span>
                        <span class="question-timer" id="questionTimer">60s</span>
                    </div>
                    <div class="question-text" id="questionText"></div>
                    <div class="options-grid" id="optionsGrid"></div>
                </div>

                <div class="quiz-progress">
                    <div class="progress-bar">
                        <div class="progress-fill" id="progressFill"></div>
                    </div>
                    <div class="progress-stats">
                        <span>Score: <span id="currentScore">0</span></span>
                        <span>Streak: <span id="currentStreak">0</span></span>
                    </div>
                </div>
            </div>

            <div class="quiz-results" id="quizResults" style="display: none;">
                <div class="results-card">
                    <h3>Quiz Complete!</h3>
                    <div class="results-stats">
                        <div class="result-stat">
                            <span class="label">Final Score</span>
                            <span class="value" id="finalScore">0/5</span>
                        </div>
                        <div class="result-stat">
                            <span class="label">Best Streak</span>
                            <span class="value" id="finalStreak">0</span>
                        </div>
                        <div class="result-stat">
                            <span class="label">Time Bonus</span>
                            <span class="value" id="timeBonus">0</span>
                        </div>
                    </div>
                    <div class="results-rewards">
                        <div class="reward-item">
                            <i class="fas fa-coins"></i>
                            <span id="coinsEarned">0 Coins</span>
                        </div>
                        <div class="reward-item">
                            <i class="fas fa-star"></i>
                            <span id="xpEarned">0 XP</span>
                        </div>
                    </div>
                    <div class="results-actions">
                        <button class="btn-play-again" id="playAgainBtn">
                            <i class="fas fa-redo"></i> Play Again
                        </button>
                        <button class="btn-back" id="backToDashboardBtn">
                            <i class="fas fa-home"></i> Back to Dashboard
                        </button>
                    </div>
                </div>
            </div>
        `;
    },

    setupEventListeners() {
        document.getElementById('startQuizBtn').addEventListener('click', () => {
            this.startQuiz();
        });

        document.getElementById('playAgainBtn').addEventListener('click', () => {
            this.startQuiz();
        });

        document.getElementById('backToDashboardBtn').addEventListener('click', () => {
            app.switchTab('dashboard');
        });
    },

    startQuiz() {
        this.currentQuestionIndex = 0;
        this.score = 0;
        this.streak = 0;
        this.timeLeft = 60;
        this.gameActive = true;

        document.querySelector('.quiz-welcome').style.display = 'none';
        document.getElementById('quizGame').style.display = 'block';
        document.getElementById('quizResults').style.display = 'none';

        this.startTimer();
        this.showQuestion();
        this.updateUI();
    },

    startQuickQuiz() {
        this.startQuiz();
        UIModule.showNotification('Quick 5-minute quiz started! Answer fast for bonus points.', 'success');
    },

    startTimer() {
        this.timer = setInterval(() => {
            this.timeLeft--;
            document.getElementById('questionTimer').textContent = `${this.timeLeft}s`;

            if (this.timeLeft <= 0) {
                this.endQuiz();
            }
        }, 1000);
    },

    showQuestion() {
        const question = this.questions[this.currentQuestionIndex];
        document.getElementById('questionNumber').textContent = `Question ${this.currentQuestionIndex + 1}/${this.questions.length}`;
        document.getElementById('questionText').textContent = question.question;

        const optionsGrid = document.getElementById('optionsGrid');
        optionsGrid.innerHTML = '';

        question.options.forEach((option, index) => {
            const optionBtn = document.createElement('button');
            optionBtn.className = 'option-btn';
            optionBtn.textContent = option;
            optionBtn.dataset.index = index;
            optionBtn.addEventListener('click', () => this.selectAnswer(index));
            optionsGrid.appendChild(optionBtn);
        });

        this.updateProgress();
    },

    selectAnswer(selectedIndex) {
        if (!this.gameActive) return;

        const question = this.questions[this.currentQuestionIndex];
        const isCorrect = selectedIndex === question.correct;

        if (isCorrect) {
            this.score++;
            this.streak++;
            UIModule.showNotification('Correct! +' + (this.streak * 10) + ' bonus points!', 'success');
        } else {
            this.streak = 0;
            UIModule.showNotification('Wrong answer. Streak reset!', 'error');
        }

        this.updateUI();

        // Show explanation
        setTimeout(() => {
            this.showExplanation(question, selectedIndex);
        }, 1000);
    },

    showExplanation(question, selectedIndex) {
        const modal = document.createElement('div');
        modal.className = 'modal active';
        modal.innerHTML = `
            <div class="modal-content explanation-modal">
                <h3>${selectedIndex === question.correct ? 'Correct!' : 'Incorrect'}</h3>
                <p><strong>Explanation:</strong> ${question.explanation}</p>
                <button class="btn-close" onclick="this.closest('.modal').remove()">Continue</button>
            </div>
        `;
        document.body.appendChild(modal);

        modal.querySelector('.btn-close').addEventListener('click', () => {
            modal.remove();
            this.nextQuestion();
        });
    },

    nextQuestion() {
        this.currentQuestionIndex++;

        if (this.currentQuestionIndex >= this.questions.length) {
            this.endQuiz();
        } else {
            this.showQuestion();
        }
    },

    updateProgress() {
        const progress = ((this.currentQuestionIndex + 1) / this.questions.length) * 100;
        document.getElementById('progressFill').style.width = `${progress}%`;
    },

    updateUI() {
        document.getElementById('currentScore').textContent = this.score;
        document.getElementById('currentStreak').textContent = this.streak;
        document.getElementById('quizStreak').textContent = this.streak;
    },

    endQuiz() {
        clearInterval(this.timer);
        this.gameActive = false;

        // Calculate rewards
        const timeBonus = Math.max(0, this.timeLeft * 2);
        const streakBonus = this.streak * 50;
        const baseReward = this.score * 100;
        const totalCoins = baseReward + timeBonus + streakBonus;
        const totalXP = this.score * 20 + Math.floor(timeBonus / 10);

        // Update user stats
        const user = UserModule.loadUser();
        user.coins += totalCoins;
        user.xp += totalXP;

        // Update quiz stats
        user.quizStats.totalCorrect += this.score;
        user.quizStats.totalAttempted += this.questions.length;
        user.quizStats.bestStreak = Math.max(user.quizStats.bestStreak, this.streak);

        UserModule.saveUser(user);

        // Check for badges
        RewardsModule.checkQuizBadges(user, (this.score / this.questions.length) * 100, this.streak);

        // Show results
        document.getElementById('quizGame').style.display = 'none';
        document.getElementById('quizResults').style.display = 'block';

        document.getElementById('finalScore').textContent = `${this.score}/${this.questions.length}`;
        document.getElementById('finalStreak').textContent = this.streak;
        document.getElementById('timeBonus').textContent = timeBonus;
        document.getElementById('coinsEarned').textContent = `${totalCoins} Coins`;
        document.getElementById('xpEarned').textContent = `${totalXP} XP`;

        // Update app
        app.updateDashboard();

        UIModule.showNotification(`Quiz complete! Earned ${totalCoins} coins and ${totalXP} XP!`, 'success');
    }
};

// Add CSS for quiz module
const quizCSS = `
<style>
.quiz-welcome {
    text-align: center;
    padding: 40px 20px;
}

.quiz-welcome h3 {
    color: #1e293b;
    margin-bottom: 15px;
}

.quiz-welcome p {
    color: #64748b;
    margin-bottom: 30px;
}

.btn-start-quiz {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    padding: 15px 30px;
    border-radius: 50px;
    font-weight: 600;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 10px;
    transition: all 0.3s ease;
}

.btn-start-quiz:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.question-card {
    background: white;
    border-radius: 15px;
    padding: 25px;
    margin-bottom: 25px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.question-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.question-number {
    font-weight: 600;
    color: #6366f1;
}

.question-timer {
    color: #ef4444;
    font-weight: 600;
}

.question-text {
    font-size: 1.2em;
    color: #1e293b;
    margin-bottom: 25px;
    line-height: 1.4;
}

.options-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 15px;
}

.option-btn {
    background: #f8fafc;
    border: 2px solid #e2e8f0;
    padding: 15px 20px;
    border-radius: 10px;
    text-align: left;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 1em;
}

.option-btn:hover {
    background: #e2e8f0;
    border-color: #cbd5e1;
}

.quiz-progress {
    background: white;
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.progress-bar {
    background: #e2e8f0;
    height: 8px;
    border-radius: 4px;
    margin-bottom: 15px;
    overflow: hidden;
}

.progress-fill {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    height: 100%;
    width: 0%;
    transition: width 0.3s ease;
}

.progress-stats {
    display: flex;
    justify-content: space-between;
    font-weight: 600;
    color: #475569;
}

.results-card {
    background: white;
    border-radius: 15px;
    padding: 30px;
    text-align: center;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    max-width: 500px;
    margin: 0 auto;
}

.results-card h3 {
    color: #1e293b;
    margin-bottom: 25px;
}

.results-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 20px;
    margin-bottom: 25px;
}

.result-stat {
    background: #f8fafc;
    padding: 15px;
    border-radius: 10px;
}

.result-stat .label {
    display: block;
    font-size: 0.9em;
    color: #64748b;
    margin-bottom: 5px;
}

.result-stat .value {
    display: block;
    font-size: 1.2em;
    font-weight: bold;
    color: #1e293b;
}

.results-rewards {
    display: flex;
    justify-content: center;
    gap: 30px;
    margin-bottom: 30px;
}

.reward-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 5px;
}

.reward-item i {
    font-size: 2em;
    color: #fbbf24;
}

.reward-item span {
    font-weight: 600;
    color: #1e293b;
}

.results-actions {
    display: flex;
    gap: 15px;
    justify-content: center;
}

.btn-play-again, .btn-back {
    padding: 12px 25px;
    border: none;
    border-radius: 25px;
    font-weight: 600;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s ease;
}

.btn-play-again {
    background: linear-gradient(135deg, #10b981, #22c55e);
    color: white;
}

.btn-back {
    background: #e2e8f0;
    color: #475569;
}

.btn-play-again:hover, .btn-back:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}

.explanation-modal {
    max-width: 400px;
}

.explanation-modal h3 {
    color: #1e293b;
    margin-bottom: 15px;
}

.explanation-modal p {
    color: #475569;
    line-height: 1.5;
    margin-bottom: 20px;
}

.btn-close {
    background: #6366f1;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 20px;
    cursor: pointer;
    font-weight: 600;
}

@media (max-width: 768px) {
    .options-grid {
        gap: 10px;
    }

    .option-btn {
        padding: 12px 15px;
        font-size: 0.9em;
    }

    .results-rewards {
        flex-direction: column;
        gap: 20px;
    }

    .results-actions {
        flex-direction: column;
    }
}
</style>
`;

document.head.insertAdjacentHTML('beforeend', quizCSS);