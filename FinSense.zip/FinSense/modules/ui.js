const UIModule = {
    showNotification(message, type = 'info') {
        const notifications = document.querySelector('.notifications');
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <i class="fas fa-${this.getNotificationIcon(type)}"></i>
            <span>${message}</span>
        `;

        notifications.appendChild(notification);

        // Remove after 5 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease forwards';
            setTimeout(() => notification.remove(), 300);
        }, 5000);
    },

    getNotificationIcon(type) {
        const icons = {
            success: 'check-circle',
            warning: 'exclamation-triangle',
            error: 'times-circle',
            info: 'info-circle'
        };
        return icons[type] || 'info-circle';
    },

    showAvatarModal() {
        const modal = document.getElementById('avatarModal');
        const grid = modal.querySelector('.avatar-grid');

        grid.innerHTML = '';

        // Generate avatar options
        for (let i = 1; i <= 12; i++) {
            const avatar = document.createElement('div');
            avatar.className = 'avatar-option';
            avatar.dataset.avatar = i;
            avatar.innerHTML = `
                <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=avatar${i}" 
                     alt="Avatar ${i}">
            `;

            avatar.addEventListener('click', () => {
                this.selectAvatar(i);
            });

            grid.appendChild(avatar);
        }

        modal.classList.add('active');

        // Close button
        document.getElementById('closeAvatar').onclick = () => {
            modal.classList.remove('active');
        };
    },

    selectAvatar(avatarId) {
        const user = UserModule.loadUser();
        user.avatar = avatarId;
        UserModule.saveUser(user);

        // Update avatar display
        document.getElementById('avatarImg').src =
            `https://api.dicebear.com/7.x/avataaars/svg?seed=avatar${avatarId}`;

        // Close modal
        document.getElementById('avatarModal').classList.remove('active');

        this.showNotification('Avatar updated!', 'success');
    },

    showConfetti() {
        const canvas = document.getElementById('confettiCanvas');
        const ctx = canvas.getContext('2d');

        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        const confettiPieces = [];
        const colors = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

        // Create confetti pieces
        for (let i = 0; i < 150; i++) {
            confettiPieces.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height - canvas.height,
                r: Math.random() * 10 + 5,
                d: Math.random() * 5 + 2,
                color: colors[Math.floor(Math.random() * colors.length)],
                tilt: Math.random() * 10 - 10,
                tiltAngleIncrement: Math.random() * 0.05 + 0.05,
                tiltAngle: 0
            });
        }

        let animationId;
        const animateConfetti = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            confettiPieces.forEach((p, i) => {
                p.y += p.d;
                p.tiltAngle += p.tiltAngleIncrement;
                p.tilt = Math.sin(p.tiltAngle) * 15;

                ctx.fillStyle = p.color;
                ctx.beginPath();
                ctx.ellipse(p.x + p.tilt, p.y, p.r, p.r / 2, Math.PI / 10, 0, Math.PI * 2);
                ctx.fill();

                // Remove piece if it's out of screen
                if (p.y > canvas.height) {
                    confettiPieces.splice(i, 1);
                }
            });

            if (confettiPieces.length > 0) {
                animationId = requestAnimationFrame(animateConfetti);
            } else {
                cancelAnimationFrame(animationId);
                ctx.clearRect(0, 0, canvas.width, canvas.height);
            }
        };

        animateConfetti();
    },

    createProgressRing(progress, element) {
        const radius = 54;
        const circumference = 2 * Math.PI * radius;
        const offset = circumference - (progress / 100) * circumference;

        element.style.strokeDasharray = `${circumference} ${circumference}`;
        element.style.strokeDashoffset = offset;
    },

    animateValue(element, start, end, duration) {
        const startTime = performance.now();

        const animate = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);

            const currentValue = Math.floor(start + (end - start) * progress);
            element.textContent = currentValue.toLocaleString();

            if (progress < 1) {
                requestAnimationFrame(animate);
            }
        };

        requestAnimationFrame(animate);
    }
};