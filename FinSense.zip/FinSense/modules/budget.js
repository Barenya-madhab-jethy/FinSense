const BudgetModule = {
    currentBudget: null,
    gameActive: false,
    currentMonth: 1,
    monthlyIncome: 25000,
    savingsGoal: 5000,
    currentBalance: 25000,
    expenses: [],
    savings: 0,
    debt: 0,

    init() {
        this.createDefaultExpenses();
        this.renderBudgetInterface();
        this.setupEventListeners();
    },

    createDefaultExpenses() {
        this.expenses = [
            { id: 'rent', name: 'Rent/House Payment', amount: 8000, category: 'Housing', fixed: true, paid: false },
            { id: 'groceries', name: 'Groceries', amount: 3000, category: 'Food', fixed: false, paid: false },
            { id: 'utilities', name: 'Utilities', amount: 2000, category: 'Housing', fixed: true, paid: false },
            { id: 'transport', name: 'Transportation', amount: 1500, category: 'Transportation', fixed: false, paid: false },
            { id: 'entertainment', name: 'Entertainment', amount: 1000, category: 'Entertainment', fixed: false, paid: false },
            { id: 'insurance', name: 'Insurance', amount: 1200, category: 'Insurance', fixed: true, paid: false },
            { id: 'misc', name: 'Miscellaneous', amount: 800, category: 'Other', fixed: false, paid: false }
        ];
    },

    renderBudgetInterface() {
        const container = document.querySelector('.budget-game');
        container.innerHTML = `
            <div class="budget-overview">
                <div class="budget-summary">
                    <div class="summary-card income">
                        <h4>Monthly Income</h4>
                        <span class="amount">₹${this.monthlyIncome.toLocaleString()}</span>
                    </div>
                    <div class="summary-card expenses">
                        <h4>Total Expenses</h4>
                        <span class="amount">₹${this.getTotalExpenses().toLocaleString()}</span>
                    </div>
                    <div class="summary-card savings">
                        <h4>Available for Savings</h4>
                        <span class="amount">₹${(this.monthlyIncome - this.getTotalExpenses()).toLocaleString()}</span>
                    </div>
                </div>
            </div>

            <div class="budget-expenses">
                <h3>Monthly Expenses</h3>
                <div class="expenses-list" id="expensesList">
                    <!-- Expenses will be populated here -->
                </div>
                <button class="btn-add-expense" id="addExpenseBtn">
                    <i class="fas fa-plus"></i> Add Expense
                </button>
            </div>

            <div class="budget-actions">
                <button class="btn-simulate" id="simulateMonthBtn">
                    <i class="fas fa-play"></i> Simulate Month
                </button>
                <button class="btn-reset" id="resetBudgetBtn">
                    <i class="fas fa-redo"></i> Reset Budget
                </button>
            </div>

            <div class="budget-results" id="budgetResults" style="display: none;">
                <div class="results-card">
                    <h3>Month ${this.currentMonth} Results</h3>
                    <div class="results-stats">
                        <div class="result-item">
                            <span>Income:</span>
                            <span>₹${this.monthlyIncome.toLocaleString()}</span>
                        </div>
                        <div class="result-item">
                            <span>Expenses:</span>
                            <span>₹${this.getTotalExpenses().toLocaleString()}</span>
                        </div>
                        <div class="result-item">
                            <span>Savings:</span>
                            <span class="${this.getMonthlySavings() >= 0 ? 'positive' : 'negative'}">
                                ₹${this.getMonthlySavings().toLocaleString()}
                            </span>
                        </div>
                        <div class="result-item">
                            <span>Balance:</span>
                            <span>₹${this.currentBalance.toLocaleString()}</span>
                        </div>
                    </div>
                    <div class="results-message">
                        <p id="resultsMessage"></p>
                    </div>
                    <button class="btn-next-month" id="nextMonthBtn">
                        Next Month
                    </button>
                </div>
            </div>
        `;

        this.renderExpenses();
        this.updateBudgetStats();
    },

    renderExpenses() {
        const expensesList = document.getElementById('expensesList');
        expensesList.innerHTML = '';

        this.expenses.forEach(expense => {
            const expenseEl = document.createElement('div');
            expenseEl.className = `expense-item ${expense.paid ? 'paid' : ''}`;
            expenseEl.innerHTML = `
                <div class="expense-info">
                    <div class="expense-name">${expense.name}</div>
                    <div class="expense-category">${expense.category}</div>
                </div>
                <div class="expense-amount">
                    <span class="amount">₹${expense.amount.toLocaleString()}</span>
                    ${expense.fixed ? '<span class="fixed-badge">Fixed</span>' : ''}
                </div>
                <div class="expense-actions">
                    <button class="btn-edit" data-id="${expense.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-delete" data-id="${expense.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
            expensesList.appendChild(expenseEl);
        });
    },

    setupEventListeners() {
        document.getElementById('addExpenseBtn').addEventListener('click', () => {
            this.showAddExpenseModal();
        });

        document.getElementById('simulateMonthBtn').addEventListener('click', () => {
            this.simulateMonth();
        });

        document.getElementById('resetBudgetBtn').addEventListener('click', () => {
            this.resetBudget();
        });

        document.getElementById('nextMonthBtn').addEventListener('click', () => {
            this.nextMonth();
        });

        // Event delegation for expense actions
        document.addEventListener('click', (e) => {
            if (e.target.closest('.btn-edit')) {
                const id = e.target.closest('.btn-edit').dataset.id;
                this.editExpense(id);
            }
            if (e.target.closest('.btn-delete')) {
                const id = e.target.closest('.btn-delete').dataset.id;
                this.deleteExpense(id);
            }
        });
    },

    showAddExpenseModal() {
        const modal = document.createElement('div');
        modal.className = 'modal active';
        modal.innerHTML = `
            <div class="modal-content">
                <h3>Add New Expense</h3>
                <form id="expenseForm">
                    <div class="form-group">
                        <label for="expenseName">Expense Name</label>
                        <input type="text" id="expenseName" required>
                    </div>
                    <div class="form-group">
                        <label for="expenseAmount">Amount (₹)</label>
                        <input type="number" id="expenseAmount" min="0" required>
                    </div>
                    <div class="form-group">
                        <label for="expenseCategory">Category</label>
                        <select id="expenseCategory" required>
                            <option value="Food">Food</option>
                            <option value="Housing">Housing</option>
                            <option value="Transportation">Transportation</option>
                            <option value="Entertainment">Entertainment</option>
                            <option value="Insurance">Insurance</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>
                            <input type="checkbox" id="expenseFixed"> Fixed expense
                        </label>
                    </div>
                    <div class="modal-actions">
                        <button type="button" class="btn-cancel" onclick="this.closest('.modal').remove()">Cancel</button>
                        <button type="submit" class="btn-save">Add Expense</button>
                    </div>
                </form>
            </div>
        `;

        document.body.appendChild(modal);

        document.getElementById('expenseForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.addExpense();
            modal.remove();
        });
    },

    addExpense() {
        const name = document.getElementById('expenseName').value;
        const amount = parseFloat(document.getElementById('expenseAmount').value);
        const category = document.getElementById('expenseCategory').value;
        const fixed = document.getElementById('expenseFixed').checked;

        const expense = {
            id: Date.now().toString(),
            name,
            amount,
            category,
            fixed,
            paid: false
        };

        this.expenses.push(expense);
        this.renderExpenses();
        this.updateBudgetStats();

        UIModule.showNotification(`Added expense: ${name}`, 'success');
    },

    editExpense(id) {
        const expense = this.expenses.find(e => e.id === id);
        if (!expense) return;

        // Similar to add modal but pre-filled
        const modal = document.createElement('div');
        modal.className = 'modal active';
        modal.innerHTML = `
            <div class="modal-content">
                <h3>Edit Expense</h3>
                <form id="editExpenseForm">
                    <div class="form-group">
                        <label for="editExpenseName">Expense Name</label>
                        <input type="text" id="editExpenseName" value="${expense.name}" required>
                    </div>
                    <div class="form-group">
                        <label for="editExpenseAmount">Amount (₹)</label>
                        <input type="number" id="editExpenseAmount" value="${expense.amount}" min="0" required>
                    </div>
                    <div class="form-group">
                        <label for="editExpenseCategory">Category</label>
                        <select id="editExpenseCategory" required>
                            <option value="Food" ${expense.category === 'Food' ? 'selected' : ''}>Food</option>
                            <option value="Housing" ${expense.category === 'Housing' ? 'selected' : ''}>Housing</option>
                            <option value="Transportation" ${expense.category === 'Transportation' ? 'selected' : ''}>Transportation</option>
                            <option value="Entertainment" ${expense.category === 'Entertainment' ? 'selected' : ''}>Entertainment</option>
                            <option value="Insurance" ${expense.category === 'Insurance' ? 'selected' : ''}>Insurance</option>
                            <option value="Other" ${expense.category === 'Other' ? 'selected' : ''}>Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>
                            <input type="checkbox" id="editExpenseFixed" ${expense.fixed ? 'checked' : ''}> Fixed expense
                        </label>
                    </div>
                    <div class="modal-actions">
                        <button type="button" class="btn-cancel" onclick="this.closest('.modal').remove()">Cancel</button>
                        <button type="submit" class="btn-save">Update Expense</button>
                    </div>
                </form>
            </div>
        `;

        document.body.appendChild(modal);

        document.getElementById('editExpenseForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.updateExpense(id);
            modal.remove();
        });
    },

    updateExpense(id) {
        const expense = this.expenses.find(e => e.id === id);
        if (!expense) return;

        expense.name = document.getElementById('editExpenseName').value;
        expense.amount = parseFloat(document.getElementById('editExpenseAmount').value);
        expense.category = document.getElementById('editExpenseCategory').value;
        expense.fixed = document.getElementById('editExpenseFixed').checked;

        this.renderExpenses();
        this.updateBudgetStats();

        UIModule.showNotification(`Updated expense: ${expense.name}`, 'success');
    },

    deleteExpense(id) {
        this.expenses = this.expenses.filter(e => e.id !== id);
        this.renderExpenses();
        this.updateBudgetStats();

        UIModule.showNotification('Expense deleted', 'info');
    },

    getTotalExpenses() {
        return this.expenses.reduce((total, expense) => total + expense.amount, 0);
    },

    getMonthlySavings() {
        return this.monthlyIncome - this.getTotalExpenses();
    },

    updateBudgetStats() {
        document.getElementById('monthlyIncome').textContent = `₹${this.monthlyIncome.toLocaleString()}`;
        document.getElementById('currentBalance').textContent = `₹${this.currentBalance.toLocaleString()}`;
    },

    simulateMonth() {
        const savings = this.getMonthlySavings();
        this.currentBalance += savings;
        this.savings += Math.max(0, savings);

        // Mark all expenses as paid
        this.expenses.forEach(expense => expense.paid = true);

        // Show results
        document.querySelector('.budget-game').style.display = 'none';
        document.getElementById('budgetResults').style.display = 'block';

        const messageEl = document.getElementById('resultsMessage');
        if (savings >= this.savingsGoal) {
            messageEl.textContent = `🎉 Excellent! You saved ₹${savings.toLocaleString()} this month, exceeding your goal of ₹${this.savingsGoal.toLocaleString()}!`;
            messageEl.className = 'positive';
        } else if (savings > 0) {
            messageEl.textContent = `👍 Good job! You saved ₹${savings.toLocaleString()} this month.`;
            messageEl.className = 'neutral';
        } else {
            messageEl.textContent = `⚠️ You spent more than you earned this month. Try reducing expenses next time!`;
            messageEl.className = 'negative';
        }

        // Update user stats
        const user = UserModule.loadUser();
        user.budgetStats = user.budgetStats || {};
        user.budgetStats.totalSaved = (user.budgetStats.totalSaved || 0) + Math.max(0, savings);
        user.budgetStats.monthsCompleted = (user.budgetStats.monthsCompleted || 0) + 1;
        user.budgetStats.debtFree = this.debt === 0;

        UserModule.saveUser(user);

        // Check for badges
        RewardsModule.checkBudgetBadges(user, user.budgetStats.totalSaved, user.budgetStats.debtFree);

        // Give rewards
        user.coins += Math.floor(savings / 100);
        user.xp += Math.floor(savings / 50);
        UserModule.saveUser(user);
    },

    nextMonth() {
        this.currentMonth++;
        this.expenses.forEach(expense => expense.paid = false);

        document.getElementById('budgetResults').style.display = 'none';
        document.querySelector('.budget-game').style.display = 'block';

        this.renderExpenses();
        UIModule.showNotification(`Starting Month ${this.currentMonth}`, 'info');
    },

    resetBudget() {
        this.currentMonth = 1;
        this.currentBalance = this.monthlyIncome;
        this.savings = 0;
        this.debt = 0;
        this.createDefaultExpenses();

        document.getElementById('budgetResults').style.display = 'none';
        document.querySelector('.budget-game').style.display = 'block';

        this.renderExpenses();
        this.updateBudgetStats();

        UIModule.showNotification('Budget reset! Starting fresh.', 'info');
    },

    startQuickBudget() {
        this.resetBudget();
        UIModule.showNotification('Quick budget simulation started! Try to save as much as possible.', 'success');
    }
};

// Add CSS for budget module
const budgetCSS = `
<style>
.budget-overview {
    margin-bottom: 30px;
}

.budget-summary {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.summary-card {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 20px;
    border-radius: 15px;
    text-align: center;
}

.summary-card.income {
    background: linear-gradient(135deg, #10b981, #22c55e);
}

.summary-card.expenses {
    background: linear-gradient(135deg, #f59e0b, #f97316);
}

.summary-card.savings {
    background: linear-gradient(135deg, #3b82f6, #1d4ed8);
}

.summary-card h4 {
    margin-bottom: 10px;
    font-size: 0.9em;
    opacity: 0.9;
}

.summary-card .amount {
    font-size: 1.5em;
    font-weight: bold;
}

.budget-expenses {
    background: #f8fafc;
    padding: 20px;
    border-radius: 15px;
    border: 2px solid #e2e8f0;
    margin-bottom: 30px;
}

.budget-expenses h3 {
    margin-bottom: 20px;
    color: #1e293b;
}

.expenses-list {
    margin-bottom: 20px;
}

.expense-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px;
    background: white;
    border-radius: 10px;
    border: 1px solid #e2e8f0;
    margin-bottom: 10px;
    transition: all 0.3s ease;
}

.expense-item.paid {
    opacity: 0.7;
    background: #f0f9ff;
}

.expense-info {
    flex: 1;
}

.expense-name {
    font-weight: 600;
    color: #1e293b;
}

.expense-category {
    font-size: 0.8em;
    color: #64748b;
    margin-top: 2px;
}

.expense-amount {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 5px;
}

.expense-amount .amount {
    font-weight: bold;
    color: #1e293b;
}

.fixed-badge {
    background: #ef4444;
    color: white;
    padding: 2px 6px;
    border-radius: 10px;
    font-size: 0.7em;
    font-weight: 600;
}

.expense-actions {
    display: flex;
    gap: 10px;
}

.btn-edit, .btn-delete {
    background: none;
    border: none;
    padding: 8px;
    border-radius: 5px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.btn-edit {
    color: #3b82f6;
}

.btn-edit:hover {
    background: #eff6ff;
}

.btn-delete {
    color: #ef4444;
}

.btn-delete:hover {
    background: #fef2f2;
}

.btn-add-expense {
    background: linear-gradient(135deg, #10b981, #22c55e);
    color: white;
    border: none;
    padding: 12px 20px;
    border-radius: 25px;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s ease;
}

.btn-add-expense:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(16, 185, 129, 0.3);
}

.budget-actions {
    display: flex;
    gap: 15px;
    justify-content: center;
    margin-bottom: 30px;
}

.btn-simulate, .btn-reset {
    padding: 15px 30px;
    border: none;
    border-radius: 50px;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 10px;
    transition: all 0.3s ease;
}

.btn-simulate {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
}

.btn-reset {
    background: linear-gradient(135deg, #f59e0b, #f97316);
    color: white;
}

.btn-simulate:hover, .btn-reset:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.results-card {
    background: white;
    border-radius: 15px;
    padding: 30px;
    text-align: center;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    max-width: 500px;
    margin: 0 auto;
}

.results-card h3 {
    color: #1e293b;
    margin-bottom: 25px;
}

.results-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 15px;
    margin-bottom: 25px;
}

.result-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px;
    background: #f8fafc;
    border-radius: 10px;
}

.result-item span:first-child {
    color: #64748b;
    font-weight: 500;
}

.result-item span:last-child {
    font-weight: bold;
    color: #1e293b;
}

.result-item .positive {
    color: #10b981;
}

.result-item .negative {
    color: #ef4444;
}

.results-message {
    margin: 25px 0;
    padding: 20px;
    border-radius: 10px;
}

.results-message.positive {
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
}

.results-message.neutral {
    background: #fefce8;
    border: 1px solid #fde68a;
}

.results-message.negative {
    background: #fef2f2;
    border: 1px solid #fecaca;
}

.results-message p {
    margin: 0;
    font-weight: 500;
}

.results-message.positive p {
    color: #166534;
}

.results-message.neutral p {
    color: #92400e;
}

.results-message.negative p {
    color: #991b1b;
}

.btn-next-month {
    background: linear-gradient(135deg, #10b981, #22c55e);
    color: white;
    border: none;
    padding: 15px 30px;
    border-radius: 50px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
}

.btn-next-month:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(16, 185, 129, 0.3);
}.modal {
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.8);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.modal.active {
    opacity: 1;
    visibility: visible;
}

.modal-content {
    background: white;
    padding: 30px;
    border-radius: 20px;
    max-width: 400px;
    width: 90%;
    max-height: 80vh;
    overflow-y: auto;
}

.modal-content h3 {
    color: #1e293b;
    margin-bottom: 20px;
    text-align: center;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: 500;
    color: #374151;
}

.form-group input,
.form-group select {
    width: 100%;
    padding: 12px;
    border: 2px solid #e5e7eb;
    border-radius: 8px;
    font-size: 1em;
    transition: border-color 0.3s ease;
}

.form-group input:focus,
.form-group select:focus {
    outline: none;
    border-color: #3b82f6;
}

.modal-actions {
    display: flex;
    gap: 15px;
    justify-content: flex-end;
    margin-top: 25px;
}

.btn-cancel, .btn-save {
    padding: 10px 20px;
    border: none;
    border-radius: 20px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
}

.btn-cancel {
    background: #e5e7eb;
    color: #374151;
}

.btn-save {
    background: linear-gradient(135deg, #10b981, #22c55e);
    color: white;
}

.btn-cancel:hover, .btn-save:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}

@media (max-width: 768px) {
    .budget-summary {
        grid-template-columns: 1fr;
    }

    .expense-item {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
    }

    .expense-amount {
        align-items: flex-start;
    }

    .budget-actions {
        flex-direction: column;
    }

    .results-stats {
        grid-template-columns: 1fr;
    }

    .modal-actions {
        flex-direction: column;
    }
}
</style>
`;

document.head.insertAdjacentHTML('beforeend', budgetCSS);