const RewardsModule = {
    badges: [{
            id: 'smart_saver',
            name: 'Smart Saver',
            icon: 'piggy-bank',
            description: 'Save ₹5,000 in Budget Simulator',
            condition: (user) => user.budgetStats ? .totalSaved >= 5000
        },
        {
            id: 'quiz_master',
            name: 'Quiz Master',
            icon: 'brain',
            description: 'Score 100% on any quiz',
            condition: (user) => user.quizStats ? .bestScore === 100
        },
        {
            id: 'streak_king',
            name: 'Streak King',
            icon: 'fire',
            description: 'Maintain a 7-day login streak',
            condition: (user) => user.streak >= 7
        },
        {
            id: 'investment_pro',
            name: 'Investment Pro',
            icon: 'chart-line',
            description: 'Earn 20% return on investments',
            condition: (user) => user.investStats ? .totalReturn >= 20
        },
        {
            id: 'debt_free',
            name: 'Debt Survivor',
            icon: 'shield-alt',
            description: 'Complete Budget Sim without debt',
            condition: (user) => user.budgetStats ? .debtFree === true
        }
    ],

    checkStreakBadge(user) {
        if (user.streak >= 7) {
            this.awardBadge(user, 'streak_king');
        }
    },

    checkQuizBadges(user, score, streak) {
        if (score === 100) {
            this.awardBadge(user, 'quiz_master');
        }

        if (streak >= 5) {
            this.awardBadge(user, 'quiz_streak');
        }
    },

    checkBudgetBadges(user, totalSaved, debtFree) {
        if (totalSaved >= 5000) {
            this.awardBadge(user, 'smart_saver');
        }

        if (debtFree) {
            this.awardBadge(user, 'debt_free');
        }
    },

    awardBadge(user, badgeId) {
        const badge = this.badges.find(b => b.id === badgeId);

        if (!badge) return;

        // Check if user already has this badge
        if (user.badges.some(b => b.id === badgeId)) {
            return;
        }

        // Award badge
        user.badges.push({
            id: badge.id,
            name: badge.name,
            icon: badge.icon,
            earnedAt: new Date().toISOString()
        });

        // Give bonus
        user.xp += 100;
        user.coins += 500;

        UserModule.saveUser(user);

        // Show notification
        UIModule.showNotification(`🏆 New Badge: ${badge.name}! +100 XP, +500 Coins`, 'success');
        UIModule.showConfetti();

        // Update app
        app.updateDashboard();
    },

    getAllBadges() {
        return this.badges;
    }
};