const InvestModule = {
    currentPortfolio: null,
    marketData: null,
    gameActive: false,
    timeInterval: null,
    currentDay: 0,

    init() {
        this.createMarketData();
        this.renderInvestmentDashboard();
        this.setupEventListeners();
    },

    loadStocks() {
        this.createMarketData();
    },

    createMarketData() {
        this.marketData = {
            stocks: [
                { id: 'tech_growth', name: 'Tech Growth Fund', price: 1500, volatility: 0.15, trend: 1.02 },
                { id: 'blue_chip', name: 'Blue Chip Stocks', price: 2500, volatility: 0.08, trend: 1.005 },
                { id: 'emerging_market', name: 'Emerging Markets', price: 800, volatility: 0.25, trend: 1.01 },
                { id: 'reit', name: 'Real Estate (REIT)', price: 1200, volatility: 0.12, trend: 1.008 },
                { id: 'crypto_coin', name: 'Crypto Coin', price: 500, volatility: 0.40, trend: 1.03 }
            ],
            fixedDeposits: [
                { id: 'fd_1yr', name: '1 Year FD', rate: 0.065, lockin: 12 },
                { id: 'fd_2yr', name: '2 Year FD', rate: 0.072, lockin: 24 },
                { id: 'fd_5yr', name: '5 Year FD', rate: 0.085, lockin: 60 }
            ],
            mutualFunds: [
                { id: 'mf_equity', name: 'Equity Fund', nav: 150, risk: 'High', category: 'Growth' },
                { id: 'mf_debt', name: 'Debt Fund', nav: 125, risk: 'Low', category: 'Income' },
                { id: 'mf_hybrid', name: 'Hybrid Fund', nav: 135, risk: 'Medium', category: 'Balanced' }
            ],
            marketEvents: [{
                    id: 'bull_market',
                    name: '📈 Bull Market',
                    effect: 1.15,
                    message: 'Market is booming! All stocks rise 15%',
                    duration: 5
                },
                {
                    id: 'bear_market',
                    name: '📉 Bear Market',
                    effect: 0.85,
                    message: 'Market correction! Prices drop 15%',
                    duration: 5
                },
                {
                    id: 'interest_rate_hike',
                    name: '🏦 Rate Hike',
                    effect: 0.95,
                    message: 'Central bank raised interest rates',
                    duration: 3
                },
                {
                    id: 'tech_boom',
                    name: '💻 Tech Boom',
                    effect: 1.25,
                    message: 'Tech sector surges! Tech stocks up 25%',
                    duration: 4
                },
                {
                    id: 'crypto_crash',
                    name: '₿ Crypto Crash',
                    effect: 0.65,
                    message: 'Crypto market crashes! Digital assets plunge',
                    duration: 3
                }
            ],
            currentEvent: null,
            eventDaysLeft: 0
        };
    },

    renderInvestmentDashboard() {
        const container = document.getElementById('invest');
        const user = UserModule.loadUser();

        container.innerHTML = `
            <div class="invest-header">
                <h2><i class="fas fa-chart-line"></i> Investment Simulator</h2>
                <div class="invest-stats">
                    <div class="stat-card">
                        <span class="label">Virtual Capital</span>
                        <span class="value" id="capitalAmount">₹${user.coins.toLocaleString()}</span>
                    </div>
                    <div class="stat-card">
                        <span class="label">Portfolio Value</span>
                        <span class="value" id="portfolioValue">₹${user.coins.toLocaleString()}</span>
                    </div>
                    <div class="stat-card">
                        <span class="label">Total Return</span>
                        <span class="value" id="totalReturn">0%</span>
                    </div>
                </div>
            </div>

            <div class="invest-game">
                <div class="game-controls">
                    <button class="btn-start" id="startInvestment">
                        <i class="fas fa-play"></i> Start 30-Day Challenge
                    </button>
                    <button class="btn-reset" id="resetPortfolio">
                        <i class="fas fa-redo"></i> Reset Portfolio
                    </button>
                    <div class="time-display">
                        <i class="fas fa-calendar-alt"></i>
                        Day: <span id="currentDay">0</span>/30
                    </div>
                </div>

                <div class="market-info">
                    <div class="event-banner" id="marketEventBanner">
                        No active market events
                    </div>
                    <div class="news-ticker" id="newsTicker">
                        📰 Market News: Initializing stock data...
                    </div>
                </div>

                <div class="investment-grid">
                    <div class="investment-section">
                        <h3><i class="fas fa-chart-bar"></i> Stock Market</h3>
                        <div class="stocks-grid" id="stocksContainer">
                            <!-- Stocks will be loaded here -->
                        </div>
                    </div>

                    <div class="investment-section">
                        <h3><i class="fas fa-shield-alt"></i> Fixed Deposits</h3>
                        <div class="fd-grid" id="fdContainer">
                            <!-- FDs will be loaded here -->
                        </div>
                    </div>

                    <div class="investment-section">
                        <h3><i class="fas fa-balance-scale"></i> Mutual Funds</h3>
                        <div class="mf-grid" id="mfContainer">
                            <!-- Mutual Funds will be loaded here -->
                        </div>
                    </div>
                </div>

                <div class="portfolio-section">
                    <h3><i class="fas fa-briefcase"></i> Your Portfolio</h3>
                    <div class="portfolio-table" id="portfolioTable">
                        <div class="portfolio-empty">
                            <i class="fas fa-chart-pie"></i>
                            <p>No investments yet. Start investing to build your portfolio!</p>
                        </div>
                    </div>
                    <div class="portfolio-stats">
                        <div class="stat">
                            <span>Diversification Score:</span>
                            <span class="score" id="diversificationScore">0/100</span>
                        </div>
                        <div class="stat">
                            <span>Risk Level:</span>
                            <span class="risk" id="riskLevel">Low</span>
                        </div>
                    </div>
                </div>

                <div class="learning-tips">
                    <h4><i class="fas fa-lightbulb"></i> Investment Tip</h4>
                    <p id="investmentTip">Diversify your portfolio across different asset classes to reduce risk.</p>
                </div>
            </div>
        `;

        this.renderInvestmentOptions();
        this.loadUserPortfolio();
    },

    renderInvestmentOptions() {
        // Render Stocks
        const stocksContainer = document.getElementById('stocksContainer');
        stocksContainer.innerHTML = this.marketData.stocks.map(stock => `
            <div class="stock-card" data-id="${stock.id}">
                <div class="stock-header">
                    <h4>${stock.name}</h4>
                    <span class="price">₹${stock.price.toLocaleString()}</span>
                </div>
                <div class="stock-info">
                    <div class="info-item">
                        <span class="label">Volatility:</span>
                        <span class="value ${stock.volatility > 0.2 ? 'high' : stock.volatility > 0.1 ? 'medium' : 'low'}">
                            ${(stock.volatility * 100).toFixed(1)}%
                        </span>
                    </div>
                    <div class="info-item">
                        <span class="label">Trend:</span>
                        <span class="value ${stock.trend > 1 ? 'up' : 'down'}">
                            ${stock.trend > 1 ? '↗ Bullish' : '↘ Bearish'}
                        </span>
                    </div>
                </div>
                <div class="stock-actions">
                    <input type="number" class="quantity-input" placeholder="Qty" min="1" max="100" 
                           data-asset="${stock.id}" data-type="stock">
                    <button class="btn-buy" data-asset="${stock.id}" data-type="stock">
                        <i class="fas fa-shopping-cart"></i> Buy
                    </button>
                </div>
            </div>
        `).join('');

        // Render Fixed Deposits
        const fdContainer = document.getElementById('fdContainer');
        fdContainer.innerHTML = this.marketData.fixedDeposits.map(fd => `
            <div class="fd-card">
                <div class="fd-header">
                    <h4>${fd.name}</h4>
                    <span class="rate">${(fd.rate * 100).toFixed(1)}% p.a.</span>
                </div>
                <div class="fd-info">
                    <div class="info-item">
                        <span class="label">Lock-in:</span>
                        <span class="value">${fd.lockin} months</span>
                    </div>
                    <div class="info-item">
                        <span class="label">Risk:</span>
                        <span class="value low">Very Low</span>
                    </div>
                </div>
                <div class="fd-actions">
                    <input type="number" class="amount-input" placeholder="₹ Amount" min="1000" step="1000"
                           data-asset="${fd.id}" data-type="fd">
                    <button class="btn-invest" data-asset="${fd.id}" data-type="fd">
                        <i class="fas fa-lock"></i> Invest
                    </button>
                </div>
            </div>
        `).join('');

        // Render Mutual Funds
        const mfContainer = document.getElementById('mfContainer');
        mfContainer.innerHTML = this.marketData.mutualFunds.map(mf => `
            <div class="mf-card">
                <div class="mf-header">
                    <h4>${mf.name}</h4>
                    <span class="nav">NAV: ₹${mf.nav}</span>
                </div>
                <div class="mf-info">
                    <div class="info-item">
                        <span class="label">Risk:</span>
                        <span class="value ${mf.risk === 'High' ? 'high' : mf.risk === 'Medium' ? 'medium' : 'low'}">
                            ${mf.risk}
                        </span>
                    </div>
                    <div class="info-item">
                        <span class="label">Category:</span>
                        <span class="value">${mf.category}</span>
                    </div>
                </div>
                <div class="mf-actions">
                    <input type="number" class="units-input" placeholder="Units" min="1" step="0.1"
                           data-asset="${mf.id}" data-type="mf">
                    <button class="btn-buy" data-asset="${mf.id}" data-type="mf">
                        <i class="fas fa-chart-pie"></i> Buy
                    </button>
                </div>
            </div>
        `).join('');
    },

    setupEventListeners() {
        // Start game button
        document.getElementById('startInvestment').addEventListener('click', () => {
            this.startGame();
        });

        // Reset portfolio button
        document.getElementById('resetPortfolio').addEventListener('click', () => {
            this.resetPortfolio();
        });

        // Buy buttons
        document.addEventListener('click', (e) => {
            if (e.target.closest('.btn-buy') || e.target.closest('.btn-invest')) {
                const button = e.target.closest('button');
                const assetId = button.dataset.asset;
                const assetType = button.dataset.type;
                const input = button.parentElement.querySelector('input');
                const quantity = parseFloat(input.value) || 0;

                if (quantity > 0) {
                    this.buyAsset(assetId, assetType, quantity);
                    input.value = '';
                } else {
                    UIModule.showNotification('Please enter a valid quantity/amount', 'warning');
                }
            }
        });
    },

    startGame() {
        if (this.gameActive) return;

        this.gameActive = true;
        this.currentDay = 0;
        this.currentPortfolio = {
            stocks: {},
            fixedDeposits: {},
            mutualFunds: {},
            cash: UserModule.loadUser().coins,
            totalInvested: 0,
            totalValue: UserModule.loadUser().coins
        };

        // Update UI
        document.getElementById('startInvestment').disabled = true;
        document.getElementById('startInvestment').innerHTML = '<i class="fas fa-sync-alt fa-spin"></i> Game Running...';

        // Start time interval (each day = 10 seconds)
        this.timeInterval = setInterval(() => {
            this.advanceDay();
        }, 10000);

        this.updateDayDisplay();
        this.generateRandomEvent();
        UIModule.showNotification('📈 Investment game started! Make smart choices!', 'success');
    },

    advanceDay() {
        if (!this.gameActive) return;

        this.currentDay++;

        // Update market prices
        this.updateMarketPrices();

        // Update portfolio value
        this.updatePortfolioValue();

        // Check for event end
        if (this.marketData.eventDaysLeft > 0) {
            this.marketData.eventDaysLeft--;
            if (this.marketData.eventDaysLeft === 0) {
                this.marketData.currentEvent = null;
                document.getElementById('marketEventBanner').innerHTML = 'No active market events';
            }
        }

        // Random event chance (10% per day)
        if (Math.random() < 0.1 && !this.marketData.currentEvent) {
            this.generateRandomEvent();
        }

        // Update display
        this.updateDayDisplay();
        this.updateNewsTicker();

        // Check game end
        if (this.currentDay >= 30) {
            this.endGame();
        }
    },

    updateMarketPrices() {
        this.marketData.stocks.forEach(stock => {
            // Base price change based on trend and volatility
            let change = (stock.trend - 1) + (Math.random() - 0.5) * stock.volatility;

            // Apply market event effect if active
            if (this.marketData.currentEvent) {
                if (stock.id.includes('tech') && this.marketData.currentEvent.id === 'tech_boom') {
                    change += 0.1;
                }
                if (stock.id.includes('crypto') && this.marketData.currentEvent.id === 'crypto_crash') {
                    change -= 0.2;
                }
                change *= this.marketData.currentEvent.effect;
            }

            // Update price (minimum price ₹100)
            stock.price = Math.max(100, stock.price * (1 + change));
            stock.price = Math.round(stock.price * 100) / 100;
        });

        // Update mutual fund NAVs
        this.marketData.mutualFunds.forEach(mf => {
            const baseChange = mf.risk === 'High' ? (Math.random() - 0.4) * 0.1 :
                mf.risk === 'Medium' ? (Math.random() - 0.3) * 0.07 :
                (Math.random() - 0.2) * 0.04;

            mf.nav = Math.max(50, mf.nav * (1 + baseChange));
            mf.nav = Math.round(mf.nav * 100) / 100;
        });

        // Re-render prices
        this.renderInvestmentOptions();
    },

    generateRandomEvent() {
        const event = this.marketData.marketEvents[Math.floor(Math.random() * this.marketData.marketEvents.length)];
        this.marketData.currentEvent = event;
        this.marketData.eventDaysLeft = event.duration;

        const banner = document.getElementById('marketEventBanner');
        banner.innerHTML = `
            <i class="fas fa-bullhorn"></i>
            <strong>${event.name}</strong>: ${event.message}
            <span class="event-timer">(${event.duration} days)</span>
        `;
        banner.className = 'event-banner active';

        // Show notification
        UIModule.showNotification(`📢 ${event.name}: ${event.message}`, 'info');

        // Update market prices immediately based on event
        this.updateMarketPrices();
    },

    buyAsset(assetId, assetType, quantity) {
        const user = UserModule.loadUser();

        if (!this.gameActive) {
            UIModule.showNotification('Start the investment game first!', 'warning');
            return;
        }

        let asset, cost;

        switch (assetType) {
            case 'stock':
                asset = this.marketData.stocks.find(s => s.id === assetId);
                cost = asset.price * quantity;
                break;
            case 'fd':
                asset = this.marketData.fixedDeposits.find(f => f.id === assetId);
                cost = quantity;
                break;
            case 'mf':
                asset = this.marketData.mutualFunds.find(m => m.id === assetId);
                cost = asset.nav * quantity;
                break;
        }

        if (cost > user.coins) {
            UIModule.showNotification('Insufficient funds!', 'error');
            return;
        }

        // Update user coins
        user.coins -= cost;
        UserModule.saveUser(user);

        // Add to portfolio
        if (!this.currentPortfolio[assetType + 's'][assetId]) {
            this.currentPortfolio[assetType + 's'][assetId] = {
                asset: asset,
                quantity: 0,
                avgPrice: 0,
                invested: 0
            };
        }

        const holding = this.currentPortfolio[assetType + 's'][assetId];
        const totalInvested = holding.invested + cost;
        const totalQuantity = holding.quantity + quantity;

        holding.avgPrice = totalInvested / totalQuantity;
        holding.quantity = totalQuantity;
        holding.invested = totalInvested;

        this.currentPortfolio.totalInvested += cost;
        this.currentPortfolio.cash = user.coins;

        // Update portfolio display
        this.updatePortfolioDisplay();

        // Show success message
        UIModule.showNotification(`✅ Bought ${quantity} ${assetType === 'fd' ? 'worth' : 'units'} of ${asset.name} for ₹${cost.toLocaleString()}`, 'success');

        // Update capital display
        document.getElementById('capitalAmount').textContent = `₹${user.coins.toLocaleString()}`;
    },

    updatePortfolioValue() {
        let totalValue = this.currentPortfolio.cash;

        // Calculate stock values
        Object.values(this.currentPortfolio.stocks).forEach(holding => {
            const currentPrice = this.marketData.stocks.find(s => s.id === holding.asset.id).price;
            holding.currentValue = currentPrice * holding.quantity;
            totalValue += holding.currentValue;
        });

        // Calculate FD values (with interest)
        Object.values(this.currentPortfolio.fixedDeposits).forEach(holding => {
            const fd = holding.asset;
            const interest = holding.invested * fd.rate * (this.currentDay / 365);
            holding.currentValue = holding.invested + interest;
            totalValue += holding.currentValue;
        });

        // Calculate MF values
        Object.values(this.currentPortfolio.mutualFunds).forEach(holding => {
            const currentNav = this.marketData.mutualFunds.find(m => m.id === holding.asset.id).nav;
            holding.currentValue = currentNav * holding.quantity;
            totalValue += holding.currentValue;
        });

        this.currentPortfolio.totalValue = totalValue;

        // Update UI
        const returnPercent = ((totalValue - 100000) / 100000 * 100).toFixed(1);
        document.getElementById('portfolioValue').textContent = `₹${Math.round(totalValue).toLocaleString()}`;
        document.getElementById('totalReturn').textContent = `${returnPercent}%`;
        document.getElementById('totalReturn').className = `value ${returnPercent >= 0 ? 'positive' : 'negative'}`;

        // Update diversification score
        this.updateDiversificationScore();
    },

    updatePortfolioDisplay() {
        const portfolioTable = document.getElementById('portfolioTable');

        if (Object.keys(this.currentPortfolio.stocks).length === 0 &&
            Object.keys(this.currentPortfolio.fixedDeposits).length === 0 &&
            Object.keys(this.currentPortfolio.mutualFunds).length === 0) {
            portfolioTable.innerHTML = `
                <div class="portfolio-empty">
                    <i class="fas fa-chart-pie"></i>
                    <p>No investments yet. Start investing to build your portfolio!</p>
                </div>
            `;
            return;
        }

        let html = `
            <div class="portfolio-header">
                <div class="header-item">Asset</div>
                <div class="header-item">Quantity</div>
                <div class="header-item">Invested</div>
                <div class="header-item">Current Value</div>
                <div class="header-item">Return</div>
            </div>
        `;

        // Add stocks
        Object.values(this.currentPortfolio.stocks).forEach(holding => {
            const currentPrice = this.marketData.stocks.find(s => s.id === holding.asset.id).price;
            const currentValue = currentPrice * holding.quantity;
            const returnAmount = currentValue - holding.invested;
            const returnPercent = (returnAmount / holding.invested * 100).toFixed(1);

            html += `
                <div class="portfolio-row">
                    <div class="row-item">
                        <i class="fas fa-chart-bar"></i>
                        ${holding.asset.name}
                    </div>
                    <div class="row-item">${holding.quantity}</div>
                    <div class="row-item">₹${holding.invested.toLocaleString()}</div>
                    <div class="row-item">₹${Math.round(currentValue).toLocaleString()}</div>
                    <div class="row-item ${returnAmount >= 0 ? 'positive' : 'negative'}">
                        ${returnAmount >= 0 ? '+' : ''}${returnPercent}%
                    </div>
                </div>
            `;
        });

        // Add fixed deposits
        Object.values(this.currentPortfolio.fixedDeposits).forEach(holding => {
            const interest = holding.invested * holding.asset.rate * (this.currentDay / 365);
            const currentValue = holding.invested + interest;
            const returnPercent = (interest / holding.invested * 100).toFixed(1);

            html += `
                <div class="portfolio-row">
                    <div class="row-item">
                        <i class="fas fa-shield-alt"></i>
                        ${holding.asset.name}
                    </div>
                    <div class="row-item">-</div>
                    <div class="row-item">₹${holding.invested.toLocaleString()}</div>
                    <div class="row-item">₹${Math.round(currentValue).toLocaleString()}</div>
                    <div class="row-item positive">+${returnPercent}%</div>
                </div>
            `;
        });

        // Add mutual funds
        Object.values(this.currentPortfolio.mutualFunds).forEach(holding => {
            const currentNav = this.marketData.mutualFunds.find(m => m.id === holding.asset.id).nav;
            const currentValue = currentNav * holding.quantity;
            const returnAmount = currentValue - holding.invested;
            const returnPercent = (returnAmount / holding.invested * 100).toFixed(1);

            html += `
                <div class="portfolio-row">
                    <div class="row-item">
                        <i class="fas fa-balance-scale"></i>
                        ${holding.asset.name}
                    </div>
                    <div class="row-item">${holding.quantity.toFixed(1)}</div>
                    <div class="row-item">₹${holding.invested.toLocaleString()}</div>
                    <div class="row-item">₹${Math.round(currentValue).toLocaleString()}</div>
                    <div class="row-item ${returnAmount >= 0 ? 'positive' : 'negative'}">
                        ${returnAmount >= 0 ? '+' : ''}${returnPercent}%
                    </div>
                </div>
            `;
        });

        portfolioTable.innerHTML = html;
    },

    updateDiversificationScore() {
        const holdings = [
            ...Object.values(this.currentPortfolio.stocks),
            ...Object.values(this.currentPortfolio.fixedDeposits),
            ...Object.values(this.currentPortfolio.mutualFunds)
        ];

        if (holdings.length === 0) {
            document.getElementById('diversificationScore').textContent = '0/100';
            document.getElementById('riskLevel').textContent = 'Low';
            return;
        }

        // Calculate diversification (more asset types = higher score)
        const assetTypes = new Set();
        holdings.forEach(h => assetTypes.add(h.asset.type || 'other'));

        let score = Math.min(100, holdings.length * 10 + assetTypes.size * 20);

        // Calculate risk level
        let riskScore = 0;
        holdings.forEach(holding => {
            if (holding.asset.volatility > 0.3) riskScore += 30;
            else if (holding.asset.volatility > 0.15) riskScore += 20;
            else if (holding.asset.risk === 'High') riskScore += 25;
            else if (holding.asset.risk === 'Medium') riskScore += 15;
            else riskScore += 5;
        });

        const avgRisk = riskScore / holdings.length;
        const riskLevel = avgRisk > 20 ? 'High' : avgRisk > 10 ? 'Medium' : 'Low';

        document.getElementById('diversificationScore').textContent = `${score}/100`;
        document.getElementById('riskLevel').textContent = riskLevel;
        document.getElementById('riskLevel').className = `risk ${riskLevel.toLowerCase()}`;
    },

    updateDayDisplay() {
        document.getElementById('currentDay').textContent = this.currentDay;
    },

    updateNewsTicker() {
        const news = [
            `Market Update: Day ${this.currentDay} of trading`,
            `Stock prices fluctuating based on market conditions`,
            this.marketData.currentEvent ? `Active Event: ${this.marketData.currentEvent.name}` : 'Market stable, no major events',
            `Portfolio Value: ₹${Math.round(this.currentPortfolio?.totalValue || 100000).toLocaleString()}`,
            `Tip: ${this.getRandomInvestmentTip()}`
        ];

        const randomNews = news[Math.floor(Math.random() * news.length)];
        document.getElementById('newsTicker').textContent = `📰 ${randomNews}`;
    },

    getRandomInvestmentTip() {
        const tips = [
            "Don't put all your eggs in one basket - diversify!",
            "Long-term investing usually beats short-term trading",
            "High returns come with high risks",
            "Start investing early to benefit from compound interest",
            "Rebalance your portfolio periodically",
            "Emergency fund should be in low-risk instruments",
            "Understand your risk tolerance before investing"
        ];
        return tips[Math.floor(Math.random() * tips.length)];
    },

    endGame() {
        clearInterval(this.timeInterval);
        this.gameActive = false;

        const finalReturn = ((this.currentPortfolio.totalValue - 100000) / 100000 * 100).toFixed(1);

        // Calculate rewards
        const user = UserModule.loadUser();
        const xpEarned = Math.max(100, Math.abs(Math.round(finalReturn * 10)));
        const coinsEarned = Math.max(500, Math.abs(Math.round(finalReturn * 100)));

        user.xp += xpEarned;
        user.coins += coinsEarned;

        // Update investment stats
        user.investStats = user.investStats || {};
        user.investStats.totalReturn = (user.investStats.totalReturn || 0) + parseFloat(finalReturn);
        user.investStats.tradesMade = (user.investStats.tradesMade || 0) +
            Object.keys(this.currentPortfolio.stocks).length +
            Object.keys(this.currentPortfolio.fixedDeposits).length +
            Object.keys(this.currentPortfolio.mutualFunds).length;

        UserModule.saveUser(user);

        // Show results modal
        this.showResultsModal(finalReturn, xpEarned, coinsEarned);

        // Check for badges
        if (parseFloat(finalReturn) >= 20) {
            RewardsModule.awardBadge(user, 'investment_pro');
        }

        // Update app
        app.updateDashboard();
    },

    showResultsModal(finalReturn, xpEarned, coinsEarned) {
        const modal = document.createElement('div');
        modal.className = 'modal active';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="result-header">
                    <i class="fas fa-trophy"></i>
                    <h2>30-Day Challenge Complete!</h2>
                </div>
                
                <div class="result-summary">
                    <div class="result-stat">
                        <span class="label">Final Portfolio Value</span>
                        <span class="value">₹${Math.round(this.currentPortfolio.totalValue).toLocaleString()}</span>
                    </div>
                    <div class="result-stat">
                        <span class="label">Total Return</span>
                        <span class="value ${finalReturn >= 0 ? 'positive' : 'negative'}">
                            ${finalReturn >= 0 ? '+' : ''}${finalReturn}%
                        </span>
                    </div>
                    <div class="result-stat">
                        <span class="label">Diversification Score</span>
                        <span class="value">${document.getElementById('diversificationScore').textContent}</span>
                    </div>
                </div>
                
                <div class="result-rewards">
                    <h3>🎉 Rewards Earned</h3>
                    <div class="rewards">
                        <div class="reward-item">
                            <i class="fas fa-star"></i>
                            <span>${xpEarned} XP</span>
                        </div>
                        <div class="reward-item">
                            <i class="fas fa-coins"></i>
                            <span>${coinsEarned} Coins</span>
                        </div>
                    </div>
                </div>
                
                <div class="result-feedback">
                    <h4>📊 Your Performance</h4>
                    <p>
                        ${finalReturn >= 20 ? 'Excellent! You beat the market!' :
                          finalReturn >= 10 ? 'Great job! Solid returns.' :
                          finalReturn >= 0 ? 'Good start! Positive returns are always good.' :
                          'Learning experience! Try diversifying more next time.'}
                    </p>
                </div>
                
                <div class="modal-actions">
                    <button class="btn-play-again" onclick="InvestModule.startGame()">
                        Play Again
                    </button>
                    <button class="btn-close" onclick="this.closest('.modal').remove()">
                        Back to Dashboard
                    </button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
    },

    resetPortfolio() {
        if (this.gameActive) {
            clearInterval(this.timeInterval);
            this.gameActive = false;
        }

        this.currentPortfolio = {
            stocks: {},
            fixedDeposits: {},
            mutualFunds: {},
            cash: UserModule.loadUser().coins,
            totalInvested: 0,
            totalValue: UserModule.loadUser().coins
        };

        this.currentDay = 0;
        this.marketData.currentEvent = null;

        // Reset UI
        document.getElementById('startInvestment').disabled = false;
        document.getElementById('startInvestment').innerHTML = '<i class="fas fa-play"></i> Start 30-Day Challenge';
        document.getElementById('marketEventBanner').innerHTML = 'No active market events';
        document.getElementById('marketEventBanner').className = 'event-banner';

        this.updatePortfolioDisplay();
        this.updatePortfolioValue();
        this.updateDayDisplay();

        UIModule.showNotification('Portfolio reset! Ready for new investments.', 'info');
    },

    loadUserPortfolio() {
        const user = UserModule.loadUser();
        if (user.investPortfolio) {
            this.currentPortfolio = user.investPortfolio;
            this.updatePortfolioDisplay();
            this.updatePortfolioValue();
        }
    },

    startQuickInvestment() {
        this.startGame();
        UIModule.showNotification('Quick investment game started! Try to maximize returns in 30 days.', 'success');
    }
};

// Add CSS for investment module
document.head.insertAdjacentHTML('beforeend', investCSS);

// Add CSS for investment module
const investCSS = `
<style>
.invest-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin: 20px 0;
}

.stat-card {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 20px;
    border-radius: 15px;
    text-align: center;
}

.stat-card .label {
    display: block;
    font-size: 0.9em;
    opacity: 0.9;
    margin-bottom: 5px;
}

.stat-card .value {
    display: block;
    font-size: 1.8em;
    font-weight: bold;
}

.game-controls {
    display: flex;
    gap: 15px;
    margin: 25px 0;
    flex-wrap: wrap;
}

.btn-start, .btn-reset {
    padding: 15px 30px;
    border: none;
    border-radius: 50px;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 10px;
    transition: all 0.3s ease;
}

.btn-start {
    background: linear-gradient(135deg, #10b981, #22c55e);
    color: white;
}

.btn-reset {
    background: linear-gradient(135deg, #f59e0b, #f97316);
    color: white;
}

.btn-start:hover, .btn-reset:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.time-display {
    background: rgba(99, 102, 241, 0.1);
    padding: 15px 25px;
    border-radius: 50px;
    display: flex;
    align-items: center;
    gap: 10px;
    font-weight: 500;
}

.market-info {
    margin: 25px 0;
}

.event-banner {
    background: linear-gradient(135deg, #f59e0b, #f97316);
    color: white;
    padding: 15px;
    border-radius: 10px;
    margin-bottom: 15px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.event-banner.active {
    animation: pulse 2s infinite;
}

.news-ticker {
    background: rgba(99, 102, 241, 0.1);
    padding: 12px 20px;
    border-radius: 10px;
    font-style: italic;
    border-left: 4px solid #6366f1;
}

.investment-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 25px;
    margin: 30px 0;
}

.investment-section {
    background: #f8fafc;
    padding: 20px;
    border-radius: 15px;
    border: 2px solid #e2e8f0;
}

.investment-section h3 {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 20px;
    color: #1e293b;
    font-size: 1.2em;
}

.portfolio-section {
    background: #f8fafc;
    padding: 20px;
    border-radius: 15px;
    border: 2px solid #e2e8f0;
    margin-top: 30px;
}

.portfolio-section h3 {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 20px;
    color: #1e293b;
    font-size: 1.2em;
}

.portfolio-table {
    margin-bottom: 20px;
}

.portfolio-empty {
    text-align: center;
    padding: 40px 20px;
    color: #64748b;
}

.portfolio-empty i {
    font-size: 3em;
    margin-bottom: 15px;
    opacity: 0.5;
}

.portfolio-header {
    display: grid;
    grid-template-columns: 2fr 1fr 1fr 1fr 1fr;
    gap: 15px;
    padding: 15px;
    background: #f1f5f9;
    border-radius: 8px;
    font-weight: 600;
    color: #475569;
    margin-bottom: 10px;
}

.portfolio-row {
    display: grid;
    grid-template-columns: 2fr 1fr 1fr 1fr 1fr;
    gap: 15px;
    padding: 15px;
    background: white;
    border-radius: 8px;
    border: 1px solid #e2e8f0;
    margin-bottom: 8px;
    align-items: center;
}

.portfolio-row .row-item {
    display: flex;
    align-items: center;
    gap: 8px;
}

.portfolio-row .row-item i {
    color: #6366f1;
}

.portfolio-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
}

.portfolio-stats .stat {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px;
    background: white;
    border-radius: 8px;
    border: 1px solid #e2e8f0;
}

.portfolio-stats .score {
    font-weight: bold;
    color: #10b981;
}

.portfolio-stats .risk {
    font-weight: bold;
}

.portfolio-stats .risk.low {
    color: #10b981;
}

.portfolio-stats .risk.medium {
    color: #f59e0b;
}

.portfolio-stats .risk.high {
    color: #ef4444;
}

.learning-tips {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 20px;
    border-radius: 15px;
    margin-top: 30px;
    text-align: center;
}

.learning-tips h4 {
    display: flex;
    align-items: center;    justify-content: center;
    margin-bottom: 15px;
    font-size: 1.1em;
}

.learning-tips p {
    font-size: 1.1em;
    opacity: 0.9;
}

.modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.8);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.modal.active {
    opacity: 1;
    visibility: visible;
}

.modal-content {
    background: white;
    padding: 30px;
    border-radius: 20px;
    max-width: 500px;
    width: 90%;
    max-height: 80vh;
    overflow-y: auto;
    text-align: center;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
}

.result-header {
    margin-bottom: 25px;
}

.result-header i {
    font-size: 3em;
    color: #fbbf24;
    margin-bottom: 15px;
}

.result-header h2 {
    color: #1e293b;
    margin: 0;
}

.result-summary {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 20px;
    margin: 25px 0;
}

.result-stat {
    background: #f8fafc;
    padding: 20px;
    border-radius: 10px;
}

.result-stat .label {
    display: block;
    font-size: 0.9em;
    color: #64748b;
    margin-bottom: 5px;
}

.result-stat .value {
    display: block;
    font-size: 1.5em;
    font-weight: bold;
    color: #1e293b;
}

.result-stat .value.positive {
    color: #10b981;
}

.result-stat .value.negative {
    color: #ef4444;
}

.result-rewards {
    margin: 25px 0;
}

.result-rewards h3 {
    color: #1e293b;
    margin-bottom: 15px;
}

.rewards {
    display: flex;
    justify-content: center;
    gap: 20px;
}

.reward-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 5px;
    padding: 15px;
    background: #f8fafc;
    border-radius: 10px;
    min-width: 80px;
}

.reward-item i {
    font-size: 1.5em;
    color: #fbbf24;
}

.reward-item span {
    font-weight: 600;
    color: #1e293b;
}

.result-feedback {
    margin: 25px 0;
    padding: 20px;
    background: #f0f9ff;
    border-radius: 10px;
    border-left: 4px solid #3b82f6;
}

.result-feedback h4 {
    color: #1e293b;
    margin-bottom: 10px;
}

.result-feedback p {
    color: #374151;
    margin: 0;
}

.modal-actions {
    display: flex;
    gap: 15px;
    justify-content: center;
    margin-top: 25px;
}

.btn-play-again, .btn-close {
    padding: 12px 25px;
    border: none;
    border-radius: 25px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
}

.btn-play-again {
    background: linear-gradient(135deg, #10b981, #22c55e);
    color: white;
}

.btn-close {
    background: #e2e8f0;
    color: #475569;
}

.btn-play-again:hover, .btn-close:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
}

@keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.05); }
    100% { transform: scale(1); }
}

@media (max-width: 768px) {
    .invest-stats {
        grid-template-columns: 1fr;
    }

    .game-controls {
        flex-direction: column;
    }

    .investment-grid {
        grid-template-columns: 1fr;
    }

    .portfolio-header,
    .portfolio-row {
        grid-template-columns: 1fr;
        gap: 10px;
    }

    .portfolio-stats {
        grid-template-columns: 1fr;
    }

    .result-summary {
        grid-template-columns: 1fr;
    }

    .rewards {
        flex-direction: column;
    }

    .modal-actions {
        flex-direction: column;
    }
}
</style>
`;