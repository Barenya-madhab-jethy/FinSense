// Main Application Controller
class FinSenseApp {
    constructor() {
        this.currentTab = 'dashboard';
        this.user = null;
        this.init();
    }

    async init() {
        // Load user data
        this.user = UserModule.loadUser();

        if (!this.user) {
            this.user = UserModule.createNewUser();
        }

        // Initialize UI
        this.initUI();
        this.initEvents();

        // Hide loading screen
        setTimeout(() => {
            document.querySelector('.loading-screen').style.opacity = '0';
            setTimeout(() => {
                document.querySelector('.loading-screen').style.display = 'none';
                this.showNotification('Welcome to FinSense!', 'success');
                this.updateDashboard();
            }, 500);
        }, 1500);
    }

    initUI() {
        // Update UI with user data
        document.getElementById('username').textContent = this.user.name;
        document.getElementById('coins').textContent = this.user.coins;
        document.getElementById('xp').textContent = this.user.xp;
        document.getElementById('level').textContent = this.user.level;
        document.getElementById('streak').textContent = this.user.streak || 0;

        // Set avatar
        const avatarImg = document.getElementById('avatarImg');
        avatarImg.src = `avatars/avatar${this.user.avatar}.png`;
        avatarImg.onerror = () => {
            avatarImg.src = 'https://ui-avatars.com/api/?name=' + this.user.name;
        };

        // Initialize tabs
        this.switchTab('dashboard');
    }

    initEvents() {
        // Tab switching
        document.querySelectorAll('.tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                const tabName = e.currentTarget.dataset.tab;
                this.switchTab(tabName);
            });
        });

        // Avatar button
        document.getElementById('avatarBtn').addEventListener('click', () => {
            UIModule.showAvatarModal();
        });

        // Daily reward
        document.getElementById('dailyReward').addEventListener('click', () => {
            this.claimDailyReward();
        });

        // Quick actions
        document.querySelectorAll('.action-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const action = e.currentTarget.dataset.action;
                this.handleQuickAction(action);
            });
        });
    }

    switchTab(tabName) {
        // Update active tab
        document.querySelectorAll('.tab').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.tab === tabName);
        });

        // Show corresponding content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.toggle('active', content.id === tabName);
        });

        this.currentTab = tabName;

        // Initialize tab-specific content
        switch (tabName) {
            case 'quiz':
                QuizModule.init();
                break;
            case 'budget':
                BudgetModule.init();
                break;
            case 'invest':
                InvestModule.init();
                break;
            case 'bank':
                BankModule.init();
                break;
            case 'achievements':
                this.showAchievements();
                break;
        }
    }

    async claimDailyReward() {
        const today = new Date().toDateString();
        const lastClaim = this.user.lastDailyClaim;

        if (lastClaim === today) {
            this.showNotification('You already claimed today\'s reward!', 'warning');
            return;
        }

        // Update streak
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);

        if (lastClaim === yesterday.toDateString()) {
            this.user.streak = (this.user.streak || 0) + 1;
        } else {
            this.user.streak = 1;
        }

        // Give reward
        const reward = 100 + (this.user.streak * 50);
        this.user.coins += reward;
        this.user.xp += 50;

        this.user.lastDailyClaim = today;
        UserModule.saveUser(this.user);

        // Update UI
        this.updateDashboard();

        // Show celebration
        UIModule.showConfetti();
        this.showNotification(`🎉 Daily Reward: +${reward} coins! Streak: ${this.user.streak}`, 'success');

        // Check for badge
        RewardsModule.checkStreakBadge(this.user);
    }

    updateDashboard() {
        // Update all displayed user stats
        document.getElementById('coins').textContent = this.user.coins;
        document.getElementById('xp').textContent = this.user.xp;
        document.getElementById('level').textContent = this.user.level;
        document.getElementById('streak').textContent = this.user.streak || 0;

        // Update progress ring
        const progress = (this.user.xp % 1000) / 10;
        const progressFill = document.querySelector('.progress-fill');
        const progressText = document.querySelector('.progress-text');

        const radius = 54;
        const circumference = 2 * Math.PI * radius;
        const offset = circumference - (progress / 100) * circumference;

        progressFill.style.strokeDasharray = `${circumference} ${circumference}`;
        progressFill.style.strokeDashoffset = offset;
        progressText.textContent = `${progress}%`;

        // Show recent badges
        this.showRecentBadges();
    }

    showRecentBadges() {
        const badgesContainer = document.getElementById('recentBadges');
        badgesContainer.innerHTML = '';

        this.user.badges.slice(0, 3).forEach(badge => {
            const badgeEl = document.createElement('div');
            badgeEl.className = 'badge';
            badgeEl.innerHTML = `
                <i class="fas fa-${badge.icon}"></i>
                <span>${badge.name}</span>
            `;
            badgesContainer.appendChild(badgeEl);
        });
    }

    showAchievements() {
        const container = document.querySelector('.achievements-grid');
        container.innerHTML = '';

        const allBadges = RewardsModule.getAllBadges();

        allBadges.forEach(badge => {
            const hasBadge = this.user.badges.some(b => b.id === badge.id);
            const badgeEl = document.createElement('div');
            badgeEl.className = `badge-achievement ${hasBadge ? 'unlocked' : 'locked'}`;
            badgeEl.innerHTML = `
                <div class="badge-icon">
                    <i class="fas fa-${badge.icon}"></i>
                </div>
                <div class="badge-info">
                    <h4>${badge.name}</h4>
                    <p>${badge.description}</p>
                </div>
                ${hasBadge ? '<span class="badge-status unlocked">✓ Unlocked</span>' : 
                            '<span class="badge-status locked">Locked</span>'}
            `;
            container.appendChild(badgeEl);
        });
    }

    handleQuickAction(action) {
        switch (action) {
            case 'quick-quiz':
                this.switchTab('quiz');
                QuizModule.startQuickQuiz();
                break;
            case 'budget-check':
                this.switchTab('budget');
                BudgetModule.startQuickBudget();
                break;
            case 'invest-now':
                this.switchTab('invest');
                InvestModule.startQuickInvestment();
                break;
        }
    }

    showNotification(message, type = 'info') {
        UIModule.showNotification(message, type);
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new FinSenseApp();
});